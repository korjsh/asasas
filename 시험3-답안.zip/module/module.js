/*
   1. 변수 number에 숫자 100을 초기화한다.
   2. 객체 myinfo에
      아이템 name에 자신의 이름을 초기화한다. 
      아이템 age에 자신의 나이를 초기화한다.
   3. number, myinfo를 내보낸다
*/

const number = 100;

const myinfo = {
   name:'장수환',
   age:31
};


module.exports = {
   number,
   myinfo
};